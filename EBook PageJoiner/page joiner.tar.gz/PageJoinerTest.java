
/**
 * Test Class for PageJoiner
 * 
 * @author Zachary Scott Evan Phillips
 */
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.*;
import java.util.Vector;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.FileReader;
import java.io.Reader;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;
import javax.swing.event.*;
import javax.swing.table.*;
import java.util.*;
import java.awt.*;
import java.io.IOException;
import java.awt.event.*;

public class PageJoinerTest extends junit.framework.TestCase
{

    public void testMain()
    {
        FileReader file = null;
        try
        {
            file = new FileReader("test2.txt");
        }

        catch (FileNotFoundException e)
        {
            System.out.println("File " + "test2.txt" + " not found.");
        }
        //testing test2.txt
        Vector<String> vector1 = fOpen("test2.txt");
        PageJoiner pageTest = new PageJoiner();
        pageTest.setLines(vector1);
        List<Integer> myList = pageTest.getCandidates(file);
        /**
         * An example of a method - replace this comment with your own
         *
         * @param  y   a sample parameter for a method
         * @return     the sum of x and y
         */

        assertEquals(2,(int)myList.get(1));
        assertEquals(3,(int)myList.get(2));
        assertEquals(4,(int)myList.get(3));
        assertEquals(6,(int)myList.get(4));

        //testing test3.txt
        FileReader file2 = null;
        try
        {
            file2 = new FileReader("test3.txt");
        }

        catch (FileNotFoundException e)
        {
            System.out.println("File " + "test3.txt" + " not found.");
        }
        Vector<String> vector2 = fOpen("test3.txt");
        PageJoiner pageTest2 = new PageJoiner();
        pageTest2.setLines(vector2);
        List<Integer> myList2 = pageTest2.getCandidates(file2);
        assertEquals(0,(int)myList2.get(0));
        assertEquals(2,(int)myList2.get(1));
        assertEquals(3,(int)myList2.get(2));
        assertEquals(4,(int)myList2.get(3));
        assertEquals(5,(int)myList2.get(4));
        assertEquals(7,(int)myList2.get(5));
        assertEquals(8,(int)myList2.get(6));
        assertEquals(10,(int)myList2.get(7));
        assertEquals(11,(int)myList2.get(8));
        assertEquals(12,(int)myList2.get(9));
        assertEquals(13,(int)myList2.get(10));
        //assertEquals(14,(int)myList2.get(11));  //last line is not a candidate

        //testing test1.txt
        FileReader file3 = null;
        try
        {
            file3 = new FileReader("test4.txt");
        }

        catch (FileNotFoundException e)
        {
            System.out.println("File " + "test4.txt" + " not found.");
        }
        Vector<String> vector3 = fOpen("test4.txt");
        PageJoiner pageTest3 = new PageJoiner();
        pageTest3.setLines(vector3);
        List<Integer> myList3 = pageTest3.getCandidates(file3);
        assertEquals(2,(int)myList3.get(0));
        assertEquals(3,(int)myList3.get(1));
        assertEquals(5,(int)myList3.get(2));
        assertEquals(7,(int)myList3.get(3));
        assertEquals(9,(int)myList3.get(4));
        assertEquals(10,(int)myList3.get(5));
        assertEquals(11,(int)myList3.get(6));
        assertEquals(12,(int)myList3.get(7));
        assertEquals(13,(int)myList3.get(8));
        assertEquals(14,(int)myList3.get(9));
        assertEquals(16,(int)myList3.get(10));
        assertEquals(17,(int)myList3.get(11));
        //assertEquals(18,(int)myList3.get(12));  //last line is not a candidate

    }

    public void testVector()
    {
        //set up
        PageJoiner pageJoiner = new PageJoiner();
        Vector<String> vector = new Vector<String>();
        //testing
        pageJoiner.setLines(vector);
        assertTrue(pageJoiner.getLines().isEmpty());

        //set up
        vector.add("newcomponent");
        pageJoiner.setLines(vector);
        //testing for component1
        assertTrue(pageJoiner.getLines().get(0).equals("newcomponent"));

        //set up
        vector.add("testline2");
        pageJoiner.setLines(vector);
        //testing again
        assertTrue(pageJoiner.getLines().get(0).equals("newcomponent"));
        assertTrue(pageJoiner.getLines().get(1).equals("testline2"));

        //testing to make sure it returns false for a string thats not there
        assertFalse(pageJoiner.getLines().contains("yo"));

    }

    public void testStringArraylist()
    {
        //set up
        PageJoiner pageJoiner = new PageJoiner();
        Vector<String> vector = new Vector<String>();
        vector.add("theend");
        vector.add("fireball");
        vector.add("your hand");
        vector.add("$300");

        FileReader rdr = null;
        try
        {
            FileReader reader = new FileReader("arrayTest.txt");
            rdr = reader;        
        }
        catch(FileNotFoundException e)
        {
        }

        pageJoiner.getCandidates(rdr);
        //testing
        assertTrue(pageJoiner.getallLines().get(0).equals("theend"));
        assertTrue(pageJoiner.getallLines().get(1).equals("fireball"));
        assertTrue(pageJoiner.getallLines().get(2).equals("your hand"));
        assertTrue(pageJoiner.getallLines().get(3).equals("$300"));
        assertFalse(pageJoiner.getallLines().contains("false"));

    }

    public void testIntArray()
    {
        //setup
        PageJoiner pageJoiner = new PageJoiner();
        int[] indices = {2, 3, 4, 5, 9, 11};
        pageJoiner.setIndices(indices);
        int[] ind = pageJoiner.getIndices();
        assertEquals(2, ind[0]);
        assertEquals(3, ind[1]);
        assertEquals(4, ind[2]);
        assertEquals(5, ind[3]);
        assertEquals(9, ind[4]);
        assertEquals(11, ind[5]);

    }
    /*
    public void testJoin()
    {
        FileReader file = null;
        try
        {
            file = new FileReader("joinTest.txt");
        }
        catch (FileNotFoundException e)
        {
            System.out.println("File " + "joinTest.txt" + " not found.");
        }
        
        
        PageJoiner joiner = new PageJoiner();
        joiner.getCandidates(file);
        
        joiner.joinLines();
        ArrayList allLines2 = joiner.getallLines();
        assertTrue("ab.".equals(allLines2.get(0)));
        assertTrue("cde!".equals(allLines2.get(1)));
        assertEquals(2, allLines2.size());
        
        
        
    }*/
    

    public static Vector<String> fOpen(String filename)
    {
        Vector<String> vector = new Vector<String>();
        FileReader file = null;
        try
        {
            file = new FileReader(filename);
        }
        catch (FileNotFoundException e)
        {
            System.out.println("File " + filename + " not found.");
        }
        Scanner scan = new Scanner(file);
        String next;
        while(scan.hasNext())
        {
            next = scan.nextLine();
            vector.add(next);
        }

        return vector;

    }

}