
/**
 * Created with Simple GUI Extension for BlueJ
 * http://home.pf.jcu.cz/~gbluej/
 */
import javax.swing.UIManager.LookAndFeelInfo;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import javax.swing.border.Border;
import javax.swing.*;
import java.util.Vector;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.FileReader;
import java.io.Reader;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;
import javax.swing.event.*;
import javax.swing.table.*;
import java.util.*;
import java.awt.*;
import java.io.IOException;
import java.awt.event.*;
/**
 * class for creating a PageJoiner Dialog Box
 */
public class JoinerDialog extends JDialog
{
    private JButton btnCancel;
    private JButton btnOK;
    private JCheckBox checkbox1;
    private JLabel lblTitle;
    private JList<String> listBox;
    private JPanel panel1;
    private ListSelectionModel listSelectionModel;
    private int[] indices;
    public static final int kWidth = 500;
    public static final int kLength = 400;
    public static final int kColor1 = 192;
    public static final int[] kBounds
    = {391, 350, 90, 35, 214, 217, 223, 12};

    /** Create this dialog from a list of Strings 
     * @param lines list of candidate lines
     */
    public JoinerDialog
    (Vector<String> lines)
    {
        this.setModal(true);
        this.setTitle("Page Joiner");
        int width = kWidth;
        int length = kLength;
        this.setSize(width, length);

        //pane with null layout

        JPanel contentPane = new JPanel(null);
        contentPane.setPreferredSize(new Dimension(width, length));
        contentPane.setBackground(new Color(kColor1, kColor1, kColor1));

        btnCancel = new JButton();
        int[] bounds = {391, 350, 90, 35, 214, 217, 223, 12};
        btnCancel.setBounds(kBounds[0], kBounds[1], kBounds[2], kBounds[3]);
        btnCancel.setBackground(new Color(kBounds[4], kBounds[5], kBounds[6]));
        btnCancel.setForeground(new Color(0, 0, 0));
        btnCancel.setEnabled(true);
        btnCancel.setFont(new Font("DejaVu Sans", 0 , kBounds[7]));
        btnCancel.setText("Cancel");
        btnCancel.setVisible(true);     
        btnCancel.addActionListener(new BtnCancelPushed());  

        btnOK = new JButton();

        btnOK.setBounds(288,350,90,35);
        btnOK.setBackground(new Color(214, 217, 223));
        btnOK.setForeground(new Color(0, 0, 0));
        btnOK.setEnabled(true);
        btnOK.setFont(new Font("DejaVu Sans", 0, 12));
        btnOK.setText("OK");
        btnOK.setVisible(true);
        btnOK.addActionListener(new BtnOKPushed());

        checkbox1 = new JCheckBox();
        checkbox1.setBounds(16, 350, 130, 35);
        checkbox1.setBackground(new Color(214, 217, 223));
        checkbox1.setForeground(new Color(0, 0, 0));
        checkbox1.setEnabled(true);
        checkbox1.setFont(new Font("DejaVu Sans", 0, 12));
        checkbox1.setText("Retain hyphens");
        checkbox1.setVisible(true);

        lblTitle = new JLabel();
        lblTitle.setBounds(7, 5, 279, 16);
        lblTitle.setBackground(new Color(214, 217, 223));
        lblTitle.setForeground(new Color(0, 0, 0));
        lblTitle.setEnabled(true);
        lblTitle.setFont(new Font("DejaVu Sans", 0, 12));
        lblTitle.setText("Select lines that should NOT be joined.");
        lblTitle.setVisible(true);

        listBox = new JList<String>(lines);
        listBox.setBounds(5, 29, 477, 311);
        listBox.setBackground(new Color(255, 255, 255));
        listBox.setForeground(new Color(0, 0, 0));
        listBox.setEnabled(true);
        listBox.setFont(new Font("Courier", 0, 12));
        listBox.setVisible(true);
        JScrollPane scrollPane = new JScrollPane(listBox);
        scrollPane.setBounds(5, 29, 477, 311);
        listListeners();

        panel1 = new JPanel(null);
        panel1.setBorder(BorderFactory.createEtchedBorder(1));
        panel1.setBounds(4, 5, 491, 390);
        panel1.setBackground(new Color(214, 217, 223));
        panel1.setForeground(new Color(0, 0, 0));
        panel1.setEnabled(true);
        panel1.setFont(new Font("DejaVu Sans", 0, 12));
        panel1.setVisible(true);

        //adding components to contentPane panel
        panel1.add(btnCancel);
        panel1.add(btnOK);
        panel1.add(checkbox1);
        panel1.add(lblTitle);
        panel1.add(scrollPane, BorderLayout.CENTER);
        contentPane.add(panel1);

        //adding panel to JFrame and seting of window position and close operation
        this.add(contentPane);
        //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.pack();
    }

    /** method to make the GUI dissapear */
    public void exitNormally()
    {
        this.setVisible(false);
    }

    /** method to add the listeners to the jlist */
    public void listListeners()
    {
        listSelectionModel = listBox.getSelectionModel();
        listSelectionModel.addListSelectionListener(
            new SharedListSelectionHandler());
    }

    /** listener for the ok button */
    class BtnOKPushed implements ActionListener
    {
        public void actionPerformed(ActionEvent btnOkGotPushed)
        {
            exitNormally();

        }
    }
    /** listener for the cancel button */
    class BtnCancelPushed implements ActionListener
    {
        public void actionPerformed(ActionEvent btnCancelGotPushed)
        {
            System.exit(0);
        }
    }
    /** listener for the jlist */
    class SharedListSelectionHandler implements ListSelectionListener 
    {
        public void valueChanged(ListSelectionEvent e) 
        { 
            ListSelectionModel lsm = (ListSelectionModel)e.getSource();

            int firstIndex = e.getFirstIndex();
            int lastIndex = e.getLastIndex();
            boolean isAdjusting = e.getValueIsAdjusting();
            // Find out which indexes are selected.
            if(isAdjusting)
            {
                indices = listBox.getSelectedIndices();

            }

        }

    }

    /** run method to run without file name needed
     * @param reader the file reader to use 
     */
    public void run(Reader reader)
    {
        PageJoiner pj = new PageJoiner();
        pj.getCandidates(reader);
        // Create the dialog
        JoinerDialog jdlg = new JoinerDialog(pj.getLines());
        // Make it visible and wait  
        //jdlg.setVisible(true);
        // After the dialog closes, do the following
        //check if skip file exists
        if(!pj.skipFileExists())
        {
            pj.setIndices(jdlg.listBox.getSelectedIndices());
        }
        //check if hyphens box was checked and set true
        if(jdlg.retainHyphens())
        {
            pj.setHyphens(true);
        }
        //or false
        else
        {
            pj.setHyphens(false);
        }
        pj.joinLines();
        pj.printLines();

    }

    /** Check if hyphens box is checked
     * @return boolean true if checked
     */
    public boolean retainHyphens()
    {
        return checkbox1.isSelected();
    }

    /** A local main for testing 
     * @param args command line arguments
     */
    public static void main(final String[] args)
    {
        javax.swing.SwingUtilities.invokeLater(new Runnable()
            {
                public void run()
                {

                    FileReader fRead = null;
                    //check if there is a command argument
                    if(args.length != 0)
                    {
                        try
                        {
                            FileReader fReader = new FileReader(args[0]);
                            fRead = fReader;
                        }
                        catch(FileNotFoundException e)
                        {
                            JOptionPane.showMessageDialog(null, "filename not found, terminating", "error message", 
                                JOptionPane.ERROR_MESSAGE); 
                            System.exit(0);
                        }
                    }
                    else
                    {
                        String newName = JOptionPane.showInputDialog
                            (null, "Enter File Name");
                        try
                        {
                            //if the user didn't enter a filename
                            if(newName == null)
                            {
                                JOptionPane.showMessageDialog(null, "filename not found, terminating", 
                                    "error message", JOptionPane.ERROR_MESSAGE); 
                                System.exit(0);
                            }
                            FileReader fReader2 = new FileReader(newName);
                            fRead = fReader2;
                        }
                        catch(FileNotFoundException e2)
                        {

                            JOptionPane.showMessageDialog(null, "filename not found, terminating", "error message", 
                                JOptionPane.ERROR_MESSAGE); 
                            System.exit(0);
                        }
                    }
                    PageJoiner pj = new PageJoiner();
                    pj.getCandidates(fRead);
                    // Create the dialog
                    JoinerDialog jdlg = new JoinerDialog(pj.getLines());
                    // Make it visible and wait  
                    if(!pj.skipFileExists())
                    {
                        pj.setIndices(jdlg.listBox.getSelectedIndices());
                    }
                    else
                    {
                        jdlg.setVisible(true);
                    }
                    // After the dialog closes, do the following
                    //check if skip file exists
                    if(!pj.skipFileExists())
                    {
                        pj.setIndices(jdlg.listBox.getSelectedIndices());
                    }
                    //if hyphens are checked set true
                    if(jdlg.retainHyphens())
                    {
                        pj.setHyphens(true);
                    }
                    //or false
                    else
                    {
                        pj.setHyphens(false);
                    }
                    pj.joinLines();
                    pj.printLines();

                }
            });
    }

}