
/**
 * Class for removing page breaks
 * 
 * @author Zachary Scott Evan Phillips
 * @version (a version number or a date)
 */

import javax.swing.UIManager.LookAndFeelInfo;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import javax.swing.border.Border;
import javax.swing.*;
import java.util.Vector;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.FileReader;
import java.io.Reader;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;
import javax.swing.event.*;
import javax.swing.table.*;
import java.util.*;
import java.awt.*;
import java.io.IOException;
import java.awt.event.*;
/**
 * Class to remove page breaks
 */

public class PageJoiner extends JDialog
{
    private boolean hyphens;  //is hyphen box checked?
    public static final int kMaxLines = 9999; //max number of lines
    public static final int kCharInGUI = 25; //lines showed in GUI
    private Vector<String> lines = new Vector<String>();  //vector of our input lines
    private ArrayList<String> allLines = 
        new ArrayList<String>();   //arraylist of all lines
    private int[] indices;  //ints indicate candidates that we dont want to join
    private ArrayList<Integer> candidates = 
        new ArrayList<Integer>();  //arraylist of all candidates

    /** Create this dialog from a list of Strings 

     */
    public PageJoiner()
    {

    }

    /** method to set the instance variable lines
     * @param lines1 the list of candidates
     */
    public void setLines(Vector<String> lines1)
    {
        lines = lines1;
    }

    public void setAllLines(ArrayList<String> allLines1)
    {
        allLines = allLines1;
    }

    /** method to get candidate lines
     * @return Vector<String> returns the list of candidate lines
     */
    public Vector<String> getLines()
    {
        return lines;
    }

    /** method to return all lines
     * @return ArrayList<String> returns list of all lines
     */
    public ArrayList<String> getallLines()
    {
        return allLines;
    }

    /** method to scan from reader the lines and fill all instance variables
     * @return List<Integer> returns a list of candidate lines
     * @param rdr the reader with the file name
     */
    public List<Integer> getCandidates(Reader rdr)
    {
        Scanner scan = new Scanner(rdr);   //scanner from input file
        String next = null;   //holder string
        int length2 = kCharInGUI;   //maxlength of line
        Vector<String> lines1 = new Vector<String>();   
        ArrayList<String> allLines1 = new ArrayList<String>();
        ArrayList<Integer> candidates1 = new ArrayList<Integer>();
        String shortLine = null;
        //gets the lines
        while(scan.hasNext())
        {
            next = scan.nextLine();
            allLines1.add(next);
        }
        //goes through all lines
        for(int ii = 0; ii < allLines1.size(); ii++)
        {
            //checking to see if the line ends without proper ending
            if(!(allLines1.get(ii).endsWith(".") || allLines1.get(ii).endsWith("!") || allLines1.get(ii).endsWith("?") || allLines1.get(ii).endsWith("\"")))
            {
                //make sure it doesnt equal the size
                if(ii != allLines1.size())
                {
                    candidates1.add(new Integer(ii));
                    //checking length
                    if(allLines1.get(ii).length() < length2)
                    {
                        length2 = allLines1.get(ii).length();
                        shortLine = allLines1.get(ii);
                    }
                    //fixing length
                    else
                    {
                        shortLine = 
                        allLines1.get(ii).substring(allLines1.get(ii).length()-length2 ,
                            allLines1.get(ii).length());
                    }
                    //checking length 
                    if(ii != allLines1.size()-1)
                    {
                        String next2 = allLines1.get(ii).format("%04d: %.25s   %.25s",
                                ii+1 , shortLine , allLines1.get(ii+1));
                        lines1.add(next2);
                    }
                }
            }
        } 
        lines = lines1;
        allLines = allLines1;
        candidates = candidates1;
        return candidates1;
    }

    /** method for setting the hyphens instance variable 
     * @param hyphens1 boolean that gives desired value of hyphens
     */      
    public void setHyphens(boolean hyphens1)
    {
        hyphens = hyphens1;
    }

    /** method to join lines 
     * 
     */
    public void joinLines()
    {
        int currentIndex = 0;
        int bb = 0;
        //going through all lines
        for(int kk = 0; kk < allLines.size(); kk++)
        {
            //checking ending punctuation
            if(!(allLines.get(kk).endsWith(".") || allLines.get(kk).endsWith("!") ||
                allLines.get(kk).endsWith("?") || 
                allLines.get(kk).endsWith("\"")))
            {
                //checking lines
                if(kk != (allLines.size()-1))
                {
                    //checking if is empty
                    if(indices.length == 0)
                    {
                        //checking hyphenated sentences
                        if(allLines.get(kk).endsWith("-"))
                        {
                            //checking whether used clicked hyphen button 
                            if(!hyphens)
                            {
                                allLines.set(kk, allLines.get(kk).substring
                                    (0, allLines.get(kk).length()-1));
                                allLines.set(kk, allLines.get(kk) + allLines.get(kk+1));
                                allLines.remove(kk+1);
                                kk--;
                            }
                            //if so leave hyphens
                            else
                            {
                                allLines.set(kk, allLines.get(kk) + allLines.get(kk+1));
                                allLines.remove(kk+1);
                                kk--;
                            }
                        }
                        //doesnt end with hyphen
                        else
                        {
                            allLines.set(kk, allLines.get(kk) + " " + 
                                allLines.get(kk+1));
                            allLines.remove(kk+1);
                            kk--;
                        }
                    }
                    //indices not empty
                    else
                    {
                        //checking if end of indices
                        if(currentIndex != indices.length)
                        {
                            //does bb == line number?
                            if(bb == indices[currentIndex])
                            {
                                currentIndex++;

                            }
                            //if not then >
                            else
                            {
                                //does it end with a hyphen
                                if(allLines.get(kk).endsWith("-"))
                                {
                                    //checking if user clicked hyphen button
                                    if(!hyphens)
                                    {
                                        allLines.set(kk, allLines.get(kk).substring
                                            (0, allLines.get(kk).length()-1));
                                        allLines.set(kk, allLines.get(kk) + 
                                            allLines.get(kk+1));
                                        allLines.remove(kk+1);
                                        kk--;
                                    }
                                    //if so leave hyphens
                                    else
                                    {
                                        allLines.set(kk, allLines.get(kk) + 
                                            allLines.get(kk+1));
                                        allLines.remove(kk+1);
                                        kk--;
                                    }
                                }
                                //doesnt end with hyphen
                                else
                                {

                                    allLines.set(kk, allLines.get(kk) + " " +
                                        allLines.get(kk+1));
                                    allLines.remove(kk+1);
                                    kk--;
                                }
                            }
                        }
                        //last line
                        else
                        {
                            //checking if ends with hyphen
                            if(allLines.get(kk).endsWith("-"))
                            {
                                //checking if hyphen button was clicked
                                if(!hyphens)
                                {
                                    allLines.set(kk, allLines.get(kk).substring
                                        (0, allLines.get(kk).length()-1));
                                    allLines.set(kk, allLines.get(kk) + 
                                        allLines.get(kk+1));
                                    allLines.remove(kk+1);
                                    kk--;
                                }
                                //if clicked then do this
                                else
                                {
                                    allLines.set(kk, allLines.get(kk) + 
                                        allLines.get(kk+1));
                                    allLines.remove(kk+1);
                                    kk--;
                                }
                            }
                            //doesnt end with hyphen
                            else
                            {

                                allLines.set(kk, allLines.get(kk) + " " +
                                    allLines.get(kk+1));
                                allLines.remove(kk+1);
                                kk--;
                            }
                        }
                    }
                }
                bb++;
            }

        }
    }

    /** method for finding out if skipfile.txt exists 
     * @return boolean true if there is a skipfile in directory
     */
    public boolean skipFileExists()
    {    
        FileReader fRead2 = null;
        boolean skipFile = false;
        //try to find a skipfile!
        try
        {
            FileReader fReader = new FileReader("skipfile.txt");
            fRead2 = fReader;
            skipFile = true;
        }
        //no skipfile found
        catch(FileNotFoundException ex)
        {
            skipFile = false;
        }
        //do this if we have a skipfile
        if(skipFile)
        {
            Scanner scan2 = new Scanner(fRead2);
            int next3 = 0;
            int[] skips = new int[kMaxLines];

            int pp = 0;
            //initiating the skipfile scan
            while(scan2.hasNext())
            {
                //make sure it has a nextInt
                if(scan2.hasNextInt())
                {
                    next3 = scan2.nextInt();
                    skips[0] = next3;
                    pp++;
                }
                //else skip it
                else
                {
                    scan2.nextLine();
                }

            }
            int[] ind = new int[pp+1];
            //giving skips array to smaller ind array
            for(int gg = 0; gg < pp; gg++)
            {
                ind[gg] = skips[gg];
            }
            indices = ind;
            return true;
        }
        //else do nothing and return false
        else
        {
            return false;
        }
    }

    /** method for setting the indices of lines to be skipped 
     * @param ind list of indices you want not joined
     */
    public void setIndices(int[] ind)
    {
        indices = ind;
    }

    /** method for getting the indices intance variable 
     * @return int[] list of indices you want not joined
     */
    public int[] getIndices()
    {
        return indices;
    }

    /** method for printing lines to a file 
     * 
     */
    public void printLines()
    {
        PrintWriter out = null;
        //try to make a new printwriter
        try
        {
            out = new PrintWriter("book.txt");
        }
        //catch exception and exit if filenotfoundexception was thrown
        catch(FileNotFoundException exp)
        {
            System.exit(0);
        }
        //printing allLines
        for(int vv = 0; vv < allLines.size(); vv++)
        {
            out.println(allLines.get(vv));
            System.out.println(allLines.get(vv));
        }
        out.close();
    }

    /** method for running the program without the user providing a filename
     * @param reader the reader with the file data in it
     */
    public void run(Reader reader)
    {
        JoinerDialog jdlg = new JoinerDialog(lines);
        jdlg.run(reader);
    }

    /**
     * @param args command line arguments
     */
    public static void main(String[] args)
    {
        Vector<String> lines1 = new Vector<String>();
        JoinerDialog jdlg = new JoinerDialog(lines1);
        jdlg.main(args);
    }
}
